<?php

require_once('Recolor.class.php');

class OpenPage extends Recolor {
	protected $foreground = 'color2';
	protected $background = 'bg_color';
	protected $filename = '/images/watstemtmijnraad/open.png';
}

?>