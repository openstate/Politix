<?php

require_once('Recolor.class.php');

class ClosePage extends Recolor {
	protected $foreground = 'color2';
	protected $background = 'bg_color';
	protected $filename = '/images/watstemtmijnraad/close.png';
}

?>