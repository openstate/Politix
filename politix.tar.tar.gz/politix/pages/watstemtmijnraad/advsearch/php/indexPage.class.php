<?php

require_once('SearchPage.class.php');

class IndexPage extends SearchPage {
	public function show($smarty) {
		parent::show($smarty);
		$smarty->assign('time', '--');
		$smarty->display('indexPage.html');
	}
}

?>