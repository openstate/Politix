<?php

require_once('LoadFormById.class.php');

class IndexPage extends LoadFormById {
	protected function getFormParameters() {
		return array('name' => 'RaadsstukEdit',
								 'header' => 'Opmaak wijzigen',
								 'submitText' => 'Wijzigen');
	}

	protected function getAction() {
		return 'edit';
	}
}

?>
