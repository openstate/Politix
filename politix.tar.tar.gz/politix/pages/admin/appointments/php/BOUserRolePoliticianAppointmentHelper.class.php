<?php

require_once('BOUserRoleAppointmentIdentityHelper.class.php');

class BOUserRolePoliticianAppointmentHelper extends BOUserRoleAppointmentIdentityHelper {}

?>