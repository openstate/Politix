<?php

require_once('BOUserRoleAppointmentIdentityHelper.class.php');

class BOUserRoleSecretaryAppointmentPartyHelper extends BOUserRoleAppointmentIdentityHelper {}

?>