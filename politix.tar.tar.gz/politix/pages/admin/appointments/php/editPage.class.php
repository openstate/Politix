<?php

require_once('LoadFormById.class.php');

class EditPage extends LoadFormById {
	protected function getFormParameters() {
		return array('name' => 'AppointmentEdit',
								 'header' => 'Aanstelling wijzigen',
								 'submitText' => 'Wijzigen',
								 'showPolitician' => false);
	}

	protected function getAction() {
		return 'edit';
	}
}

?>
