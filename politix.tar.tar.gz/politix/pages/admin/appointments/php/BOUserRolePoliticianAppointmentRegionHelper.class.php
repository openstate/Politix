<?php

require_once('BOUserRolePoliticianAppointmentPartyHelper.class.php');

class BOUserRolePoliticianAppointmentRegionHelper extends BOUserRolePoliticianAppointmentPartyHelper {}

?>