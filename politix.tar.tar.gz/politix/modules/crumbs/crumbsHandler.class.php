<?php

class crumbsHandler {
	public $urlMap = array();
}

?>