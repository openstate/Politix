<?php

//require_once('Answer.class.php');

class Site extends Record {
	protected $tableName = 'sys_site';
	
	protected $data = array(
		'id' 		 => null,
		'title'       => null,
	);
	
	

}

?>
