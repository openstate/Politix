<?php
class Level extends Record {

	protected $data = array('name' => null);	
	protected $tableName = 'sys_levels';	

	
}

?>