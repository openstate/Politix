<?php /* Smarty version 2.6.18, created on 2008-12-16 13:31:31
         compiled from /var/www/projects/politix/public_html/../pages/admin/raadsstukken/php/../content/options.html */ ?>

<input type="hidden" name="<?php echo $this->_tpl_vars['prefix']; ?>
" class="<?php echo $this->_tpl_vars['class']; ?>
 vote" value="<?php echo $this->_tpl_vars['set']; ?>
"/>
<div class="vote-item undefined"><div style="float: right">&raquo;</div><span class="vote-text">Geen</span></div>