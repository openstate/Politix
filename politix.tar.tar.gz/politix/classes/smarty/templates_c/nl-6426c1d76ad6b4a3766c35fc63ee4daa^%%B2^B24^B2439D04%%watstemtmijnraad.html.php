<?php /* Smarty version 2.6.18, created on 2008-12-02 17:21:38
         compiled from /var/www/projects/politix/emails/watstemtmijnraad/watstemtmijnraad.html */ ?>
<html style="height:100%;">
<body bgcolor="FFFFFF" style="background-color: #FFFFFF;height:100%;">
	<font face="Arial" color="83083A" style="color:#83083A;font-family:Arial;font-size: 12px;" size="2">

		<table bgcolor="FFCC00" style="background-color: #FFCC00;height:100%;" cellpadding="4" cellspacing="0" height="100%">
			<tr>
				<td bgcolor="F08E07" style="background-color: #F08E07;">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				</td>

				<td valign="top" style="text-align:top;padding-left:10px;">
					<font face="Arial" color="83083A" style="color:#83083A;font-family:Arial;font-size: 12px;" size="2">
						<br><br><br>
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => $this->_tpl_vars['smartyData']['contentFile'], 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
					</font>
				</td>
			</tr>

		</table>

	</font>
</body>
</html>