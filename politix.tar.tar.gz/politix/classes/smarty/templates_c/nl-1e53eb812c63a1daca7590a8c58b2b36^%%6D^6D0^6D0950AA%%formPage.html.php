<?php /* Smarty version 2.6.18, created on 2009-04-03 10:11:41
         compiled from /var/www/projects/politix/pages/admin/politicians/header/formPage.html */ ?>
<script type="text/javascript" src="/javascripts/formValidation.js"></script>