<?php /* Smarty version 2.6.18, created on 2009-04-03 10:11:46
         compiled from /var/www/projects/politix/pages/admin/appointments/header/indexPage.html */ ?>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
<?php echo '

window.addEvent(\'domready\', function() {
	$$(\'tr.link\').addEvent(\'click\', function() {
		document.location.href = $E(\'a.edit\', this).href;
	});
});

'; ?>

//--><!]]>
</script>
