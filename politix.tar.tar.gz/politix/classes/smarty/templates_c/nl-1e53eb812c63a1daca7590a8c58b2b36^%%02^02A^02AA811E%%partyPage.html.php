<?php /* Smarty version 2.6.18, created on 2009-06-09 11:40:38
         compiled from /var/www/projects/politix/pages/admin/appointments/header/partyPage.html */ ?>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
<?php echo '

window.addEvent(\'domready\', function() {
	$$(\'tr.link\').addEvent(\'click\', function() {
		document.location.href = $E(\'a.app\', this).href;
	});
});

'; ?>

//--><!]]>
</script>
