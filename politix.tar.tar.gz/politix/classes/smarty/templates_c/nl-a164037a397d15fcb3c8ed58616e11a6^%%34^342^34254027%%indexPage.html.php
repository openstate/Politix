<?php /* Smarty version 2.6.18, created on 2009-02-17 10:08:45
         compiled from /var/www/projects/politix/modules/user/pages/login/content/indexPage.html */ ?>

<h2>Inloggen</h2>
<div class="block" id="loginForm">
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyData']['contentDir'])."/indexPageBase.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<p>
<a href="/login/password/" class="formLink">Wachtwoord vergeten?</a><br />
</p>
</div>