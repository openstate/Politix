<?php /* Smarty version 2.6.18, created on 2008-12-16 13:24:51
         compiled from /var/www/projects/politix/modules/user/pages/admin//roles/php/../header//createPageBase.html */ ?>
<?php echo '<script type="text/javascript">
<!--
function updateVisibility(form) {
	
}

function clearErrors() {
			document.getElementById(\'_err_title_0\').style.display = \'none\';

}

function validate(form) {
	var maySubmit = true;
			if (!form[\'title\'].value!=\'\') { document.getElementById(\'_err_title_0\').style.display = \'\'; maySubmit = false; }

//	if (!maySubmit)
//		location.hash = \'EditableRoleCreate\';
	return maySubmit;
}

// -->
</script>'; ?>