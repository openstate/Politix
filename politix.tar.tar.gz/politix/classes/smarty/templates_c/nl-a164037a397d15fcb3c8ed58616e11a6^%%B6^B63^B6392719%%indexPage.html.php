<?php /* Smarty version 2.6.18, created on 2008-12-02 09:40:08
         compiled from /var/www/projects/politix/modules/dbpages/pages/view/content/indexPage.html */ ?>
<div class="titleBlock"></div><h2><?php echo $this->_tpl_vars['page']->title; ?>
</h2>

<div class="contentBlock">
	<?php echo $this->_tpl_vars['page']->content; ?>

</div>