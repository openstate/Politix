<?php /* Smarty version 2.6.18, created on 2008-12-02 09:43:26
         compiled from /var/www/projects/politix/templates/404.html */ ?>

<div class="titleBlock"></div><h2>404 Pagina niet gevonden</h2>
<p class="i">De opgevraagde URL <?php echo $this->_tpl_vars['data']['url']; ?>
 kon niet worden gevonden op deze server.</p>