<?php /* Smarty version 2.6.18, created on 2008-12-16 13:24:51
         compiled from /var/www/projects/politix/modules/user/pages/admin/roles/header/createPage.html */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyData']['headerDir'])."/createPageBase.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>