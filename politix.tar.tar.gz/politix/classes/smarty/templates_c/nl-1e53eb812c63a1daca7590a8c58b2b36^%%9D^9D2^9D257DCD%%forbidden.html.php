<?php /* Smarty version 2.6.18, created on 2009-02-16 09:32:45
         compiled from /var/www/projects/politix/templates/forbidden.html */ ?>

<h2>Toegang geweigerd</h2>
<p>U heeft niet de rechten om deze pagina (<?php echo $this->_tpl_vars['data']['url']; ?>
) te zien.</p>