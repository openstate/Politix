<?php /* Smarty version 2.6.18, created on 2008-12-16 13:11:02
         compiled from /var/www/projects/politix/pages/admin/home/content/indexPage.html */ ?>
<h2>Welkom in de backoffice van Politix. U kunt rechtsbovenin inloggen.</h2>