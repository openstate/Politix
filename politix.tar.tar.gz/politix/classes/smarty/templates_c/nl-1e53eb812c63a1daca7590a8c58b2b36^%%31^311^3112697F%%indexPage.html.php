<?php /* Smarty version 2.6.18, created on 2008-12-16 13:24:45
         compiled from /var/www/projects/politix/modules/user/pages/admin/roles/content/indexPage.html */ ?>

<h2>Rollen</h2>
<p><a href="/users/roles/create/"><img src="/images/add.png" alt="Toevoegen" title="Toevoegen" border="0"/></a> <a href="/users/roles/create/">Toevoegen</a></p>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyData']['contentDir'])."/indexPageBase.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>