<?php

class BaseUserFactory {
	public static function create() {
		return new User();
	}
}

?>