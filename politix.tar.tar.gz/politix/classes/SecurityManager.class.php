<?php

interface SecurityManager {
	public function isAllowed($id);

	public function forbidden();
}

?>