<?php

class SecurityException extends Exception {

}

?>