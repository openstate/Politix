<?php

/**
* Some value is not set/found, but is required.
*
* @author Sardar Yumatov (ja.doma@gmail.com)
*/
class NotFoundException extends RuntimeException {

}

?>