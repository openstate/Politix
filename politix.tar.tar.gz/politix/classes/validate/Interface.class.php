<?php

interface Validate_Interface {
	public function isValid($email);
}

?>